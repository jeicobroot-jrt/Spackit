import sys

def run():
    print("📦 [spackit] v0.1.0 inicializado...")
    print("¡Qué lo qué! El sistema está corriendo spackit sin problemas.")
    # Un pequeño toque extra: ver qué versión de Python usa
    print(f"Corriendo sobre Python {sys.version.split()[0]}")

if __name__ == "__main__":
    run()
